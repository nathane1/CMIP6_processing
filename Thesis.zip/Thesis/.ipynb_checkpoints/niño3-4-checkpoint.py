# Code to calculate Niño 3.4 index for CMIP6 data
# Author: Nathan Erickson
# Date: 11/8/2021
# Coded with Python 3.8.10

# Initialize system variables

import sys

model = sys.argv[1]
f = sys.argv[2]
mask = sys.argv[3]

# Directory management

import os

dir = '/chinook2/nathane1/Thesis/CMIP6/'
path = dir + model
os.chdir(path)

# Manipulate file paths to maximize future usability

from cmip6_processing import model_formatter
filename = f.split('CMIP6')[1]
realization_file = filename.split(f'{model}/')[1]
realization = realization_file.split('.nc')[0]
format_realization = model_formatter(realization)

# Print a couple of sanity checks to the screen

print('---------------------------------------')
print('Starting run for', model)
print('Model data to be used is', filename)
print('Land mask for file is', mask)
print('Realization is', format_realization)

# Import other important modules

import numpy as np
import pandas as pd
import xarray as xr
import datetime
import warnings

warnings.simplefilter("ignore","SerializationWarning:")

# Read in files from working directory
# Read in model data

data = xr.open_dataset(f'{dir}{filename}')

# Read in land mask

try:
    land_mask = xr.open_dataset(f'{mask}')
except FileNotFoundError:
    print("------------------------------------------")
    print(f"Land mask doesn't exist for {model}; no appropriate reprojection can be done")
    print("------------------------------------------")

# Assign data arrays to variables; mask out land surfaces

ts = data['ts']
if model != "MCM-UA-1-0":
    lon = data['lon']
    lat = data['lat']
else:
    lon = data['longitude']
    lat = data['latitude']

land_masked = ts.where(land_mask['sftlf'] != 100)

def calculate_niño(ssts): 
    sst_anomalies= []
    
    # Select Niño 3.4 region
    ts_nino = ssts.sel(lon=slice(120,170),lat=slice(-5,5)) # <- Make sure to change me when switching between obs/model runs
    average_ts = ts_nino.mean(['lat','lon'])
    
    # Establish a background climatology to use for Niño 3.4 calculation
    avg_timesteps = 5 # Need to generalize the amount of timesteps
    
    try:
        average_jan = average_ts.loc[[np.datetime_as_string(average_ts['time'].values)[time][5:7]  == '01' for time in range(len(average_ts['time'].values))]]
        average_feb = average_ts.loc[[np.datetime_as_string(average_ts['time'].values)[time][5:7]  == '02' for time in range(len(average_ts['time'].values))]]
        average_dec = average_ts.loc[[np.datetime_as_string(average_ts['time'].values)[time][5:7]  == '12' for time in range(len(average_ts['time'].values))]]
    except TypeError:
        print("Looks like those aren't numpy datetimes, let's try a more general datetime approach.")
        pass
        try: 
            date_format = '%Y-%m-%d %H:%M:%S'
            average_jan = average_ts.loc[[datetime.datetime.strptime(str(data['time'][time].values), date_format).strftime(date_format)[5:7] == '01' for time in range(len(average_ts['time'].values))]]
            average_feb = average_ts.loc[[datetime.datetime.strptime(str(data['time'][time].values), date_format).strftime(date_format)[5:7] == '02' for time in range(len(average_ts['time'].values))]]
            average_dec = average_ts.loc[[datetime.datetime.strptime(str(data['time'][time].values), date_format).strftime(date_format)[5:7] == '12' for time in range(len(average_ts['time'].values))]]
        except TypeError:
            print("These datetimes are a real mess and need to be handled singularly in new code.")
                     
    clima_jan = average_jan.rolling(time = avg_timesteps, center = True).mean()
    clima_feb = average_feb.rolling(time = avg_timesteps, center = True).mean()
    clima_dec = average_dec.rolling(time = avg_timesteps, center = True).mean()

    clima_jan[0:15] = clima_jan[0:15].fillna(value = clima_jan[16])
    clima_jan[-15:] = clima_jan[-15:].fillna(value = clima_jan[-16])
    clima_feb[0:15] = clima_feb[0:15].fillna(value = clima_feb[16])
    clima_feb[-15:] = clima_feb[-15:].fillna(value = clima_feb[-16])
    clima_dec[0:15] = clima_dec[0:15].fillna(value = clima_dec[16])
    clima_dec[-15:] = clima_dec[-15:].fillna(value = clima_dec[-16])
    
    # Calculate Niño 3.4 index for the dataset
    for t in range(0,len(ts_nino)):
        try:
            jan_anom = float((average_jan[t] - clima_jan[t]).values)
            feb_anom = float((average_feb[t] - clima_feb[t]).values)
            dec_anom = float((average_dec[t] - clima_dec[t]).values)
            sst_anomalies.append(jan_anom)
            sst_anomalies.append(feb_anom)
            sst_anomalies.append(dec_anom)
        except:
            break
            print("Calculation failed :(")
    
    return sst_anomalies
        
sst_anomalies = calculate_niño(land_masked)
print(f"Successfully calculated Niño 3.4 index for {format_realization}!")

# Send output to CSV

niño_output = pd.read_csv('/home/nathane1/Thesis/output/niño_3.4_table.csv')
niño_series = pd.Series(sst_anomalies, name= format_realization)
niño_output.insert(0, format_realization, niño_series)
niño_output.to_csv('/home/nathane1/Thesis/output/niño_3.4_table.csv')

# Send a nice message to the screen

print("-------------------------------------------------")
print(f"Successfully output realization {format_realization} for {model}!")
print("-------------------------------------------------")