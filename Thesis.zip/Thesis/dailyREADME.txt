9/15/2021 - Need to download ERSST_v5 data tomorrow to verify if ELI calculation is actually working correctly or not

9/27/2021 - Shell script is correctly iterating; need to save data from the Python script so that it can actually be used in creating plots later on

9/28/2021 - Need to make columns for each model to plot later
    Need header - set as model name
    Data is ELI array
    
Models missing land masks: CanESM5-CanOE, CIESM(?), FIO-ESM-2-0(?), IITM-ESM(?), KACE-1-0-G, KIOST-ESM(?), MCM-UA-1-0, UKESM1-0-LL
    -Keep some residual land mask loaded in the background?
    
9/29/2021 - Searching for land masks...
    Definitely missing masks: CanESM5-CanOE, CIESM, FIO-ESM-2-0, IITM-ESM,
    KACE-1-0-G, KIOST-ESM, MCM-UA-1-0, UKESM1-0-LL
    
10/4/2021 - Need to find a matching projection to include a land mask for the above models:
    Models:        Projection:                Nominal Resolution:        Match:
    CanESM5-CanOE  T63 Linear Gaussian Grid   500km
    CIESM          gs1x1                      100km
    FIO-ESM-2-0    native atmosphere regular  100km
    IITM-ESM       gs2x2                      250km
    KACE-1-0-G     gs1x1                      250km
    KIOST-ESM      regridded from cS          250km
    MCM-UA-1-0     lat-lon                    250km
    UKESM1-0-LL    Native N96 grid            250km
    
Spots where the shell script breaks (excluding missing land mask):

!!!CESM2: issubclass (!?!?)

To-do tomorrow:
- Run script while ignoring CESM2/models missing land mask
- Make figures

10/5/2021 - Shell script being run for all models
- Need to rerun for models missing land masks, CESM2/CESM2-WACCM, MPI-ESM2-1-LR,
EC-Earth (everything after r3), EC-Earth-Veg (r6)

10/12/2021 - To-do tomorrow:
                -Heatmaps for all members of one ensemble
                -Box plots (50-year periods)
                
10/19/2021 - Things to clean up in future:
                Make string formatting a function
                Make index setting on CSV's a function
                
           - Tomorrow:
               Read in El Niño/La Niña data for comparison boxplots
               
11/28/2021 - Models that got missed in the Niño 3.4 calculation:
                CESM2/CESM2-WACCM - Is subclass issue
                GFDL-CM4 - Needs different datetime - Solved
                GFDL-ESM4 - Needs different datetime - Solved
                GISS-E2-1-G - Needs different datetime - Solved
                HadGEM3-GC31-LL - Needs different datetime - Solved
                HadGEM3-GC31-MM - Needs different datetime - Solved
                INM-CM4-8 - Needs different datetime - Solved
                INM-CM5-0 - Needs different datetime - Solved
                NorESM2-LM - Needs different datetime - Solved
                NorEMS2-MM - Needs different datetime - Solved
                TaiESM1 - Needs different datetime - Solved
                
3/22/2022 - Need to run for SST bias/evolution plots:
            ACCESS-CM2 - Done
            ACCESS-ESM1-5 - Done
            AWI-CM-1-1-MR - Done
            BCC-CSM2-MR - Done
            CAMS-CSM1-0 - Done
            CanESM5 - Done
            CMCC-CM2-SR5 - Done
            CNRM-CM6-1 - Done
            CNRM-CM6-1-HR - Done
            EC-Earth3 - Merge error; needs to be scouted (lat dimensions don't match)
            EC-Earth3-Veg - Merge error; needs to be scouted (lat dimensions don't match)
            FGOALS-f3-L - Done
            FGOALS-g3 - Lacks unique index
            GFDL-CM4 - Done
            GFDL-ESM4 - Done
            GISS-E2-1-G - Done
            HadGEM3-GC31-LL - Done
            HadGEM3-GC31-MM - Done
            INM-CM4-8 - Done
            INM-CM5-0 - Done
            IPSL-CM6A-LR - Done
            MIROC6 - Done
            MIROC-ES2L - Done
            MPI-ESM1-2-HR - Done
            NESM3 - Done
            NorESM2-LM - Done
            NorESM2-MM - Done
            TaiESM1 - Done
            
4/8/2022 - Need to run for zonal average plots
            EC-Earth3 - Merge error; needs to be scouted (lat dimensions don't match)
            EC-Earth3-Veg - Merge error; needs to be scouted (lat dimensions don't match)
            FGOALS-g3 - Lacks unique index
            MIROC6 - Crashes kernel (try in terminal?)